#!/sbin/sh

echo "camera.hal1.packagelist=com.google.android.GoogleCamera" >> /system/build.prop
echo "camera.hal1.packagelist=com.google.android.GoogleCamera" >> /vendor/build.prop
